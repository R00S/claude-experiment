# Inside the container — install a text editor
apt-get update && apt-get install -y nano
nano /app/src/ha_client.py