docker exec ha-dev-orchestrator head -5 /app/src/ha_client.py
docker restart ha-dev-orchestrator