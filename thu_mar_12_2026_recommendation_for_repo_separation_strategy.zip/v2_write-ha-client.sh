docker exec ha-dev-orchestrator sh -c 'cat > /app/src/ha_client.py << '"'"'EOF'"'"'
"""Async client for the Home Assistant REST and WebSocket APIs."""

import asyncio
import json
import os

import aiohttp
import websockets


HA_URL = os.environ.get("HA_URL", "http://homeassistant.local:8123")
HA_TOKEN = os.environ.get("HA_TOKEN", "")

_WS_MAX_SIZE = 20_000_000


def _rest_headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {HA_TOKEN}",
        "Content-Type": "application/json",
    }


def _ws_url() -> str:
    base = HA_URL.rstrip("/")
    if base.startswith("https://"):
        return base.replace("https://", "wss://") + "/api/websocket"
    return base.replace("http://", "ws://") + "/api/websocket"


async def _ws_send_command(command: dict) -> dict:
    async with websockets.connect(_ws_url(), max_size=_WS_MAX_SIZE) as ws:
        msg = json.loads(await ws.recv())
        if msg.get("type") != "auth_required":
            raise RuntimeError(f"Unexpected WS message: {msg}")
        await ws.send(json.dumps({"type": "auth", "access_token": HA_TOKEN}))
        msg = json.loads(await ws.recv())
        if msg.get("type") != "auth_ok":
            raise RuntimeError(f"WS auth failed: {msg}")
        command.setdefault("id", 1)
        await ws.send(json.dumps(command))
        msg = json.loads(await ws.recv())
        if not msg.get("success", False):
            raise RuntimeError(f"WS command failed: {msg}")
        return msg.get("result", {})


async def get_states(entity_filter: str = "") -> list[dict]:
    url = f"{HA_URL}/api/states"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            states = await resp.json()
    if entity_filter:
        states = [s for s in states if s["entity_id"].startswith(entity_filter)]
    return states


async def get_error_log(domain: str = "", since_minutes: int = 30) -> str:
    url = f"{HA_URL}/api/error_log"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            log_text = await resp.text()
    if domain:
        log_text = "\n".join(
            line for line in log_text.splitlines() if domain in line
        )
    return log_text


async def check_integration_loaded(domain: str) -> bool:
    url = f"{HA_URL}/api/config"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            config = await resp.json()
    return domain in config.get("components", [])


async def call_service(domain: str, service: str, data: dict | None = None) -> dict:
    url = f"{HA_URL}/api/services/{domain}/{service}"
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=data or {}, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            return await resp.json()


async def restart_and_wait(timeout_seconds: int = 180) -> bool:
    url = f"{HA_URL}/api/services/homeassistant/restart"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, json={}, headers=_rest_headers(),
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
    except (aiohttp.ClientError, OSError, asyncio.TimeoutError):
        pass
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_seconds
    await asyncio.sleep(10)
    while loop.time() < deadline:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{HA_URL}/api/",
                    headers=_rest_headers(),
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        return True
        except (aiohttp.ClientError, OSError, asyncio.TimeoutError):
            pass
        await asyncio.sleep(5)
    return False


async def hacs_add_repository(repository: str, category: str = "integration") -> dict:
    return await _ws_send_command({
        "type": "hacs/repositories/add",
        "repository": repository,
        "category": category,
    })


async def hacs_install(repository: str, version: str = "") -> dict:
    try:
        await hacs_add_repository(repository)
    except RuntimeError:
        pass
    command: dict = {
        "type": "hacs/repository/download",
        "repository": repository,
    }
    if version:
        command["version"] = version
    return await _ws_send_command(command)


async def hacs_list_repositories() -> list[dict]:
    return await _ws_send_command({"type": "hacs/repositories/list"})


async def remove_config_entries(domain: str) -> int:
    entries = await _ws_send_command({"type": "config_entries/get"})
    removed = 0
    if isinstance(entries, list):
        for entry in entries:
            if entry.get("domain") == domain:
                await _ws_send_command({
                    "type": "config_entries/delete",
                    "entry_id": entry["entry_id"],
                })
                removed += 1
    return removed
EOF'