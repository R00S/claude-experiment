# From TrueNAS shell (not inside the container)
curl -s -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  http://192.168.1.37:8123/api/ | head -20