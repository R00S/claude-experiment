# Check if HACS is in the loaded components list
curl -s -H "Authorization: Bearer YOUR_TOKEN" \
  http://192.168.1.37:8123/api/config | python3 -m json.tool | grep hacs