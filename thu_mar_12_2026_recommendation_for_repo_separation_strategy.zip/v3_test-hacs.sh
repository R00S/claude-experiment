python3.13 -m pip install websockets && python3.13 -c "
import asyncio, json, websockets
async def test():
    async with websockets.connect('ws://192.168.1.37:8123/api/websocket') as ws:
        print(await ws.recv())
        await ws.send(json.dumps({'type': 'auth', 'access_token': 'YOUR_TOKEN'}))
        print(await ws.recv())
        await ws.send(json.dumps({'id': 1, 'type': 'hacs/repositories/list'}))
        resp = json.loads(await ws.recv())
        print(f'Success: {resp.get(\"success\")}')
        if resp.get('success'):
            print(f'HACS repos: {len(resp.get(\"result\", []))}')
        else:
            print(f'Error: {resp}')
asyncio.run(test())
"