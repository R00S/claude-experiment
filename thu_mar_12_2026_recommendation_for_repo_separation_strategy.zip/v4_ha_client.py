"""Async client for the Home Assistant REST and WebSocket APIs."""

import asyncio
import json
import os

import aiohttp
import websockets


HA_URL = os.environ.get("HA_URL", "http://homeassistant.local:8123")
HA_TOKEN = os.environ.get("HA_TOKEN", "")

# Large enough for HACS full catalog responses (~2-5 MB)
_WS_MAX_SIZE = 20_000_000

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _rest_headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {HA_TOKEN}",
        "Content-Type": "application/json",
    }


def _ws_url() -> str:
    """Return the WebSocket URL derived from HA_URL."""
    base = HA_URL.rstrip("/")
    if base.startswith("https://"):
        return base.replace("https://", "wss://") + "/api/websocket"
    return base.replace("http://", "ws://") + "/api/websocket"


async def _ws_send_command(command: dict) -> dict:
    """Open an authenticated WebSocket connection, send *command*, return the result."""
    async with websockets.connect(_ws_url(), max_size=_WS_MAX_SIZE) as ws:
        # Server sends auth_required
        msg = json.loads(await ws.recv())
        if msg.get("type") != "auth_required":
            raise RuntimeError(f"Unexpected WS message: {msg}")

        # Authenticate
        await ws.send(json.dumps({"type": "auth", "access_token": HA_TOKEN}))
        msg = json.loads(await ws.recv())
        if msg.get("type") != "auth_ok":
            raise RuntimeError(f"WS auth failed: {msg}")

        # Send the actual command (id must be >0)
        command.setdefault("id", 1)
        await ws.send(json.dumps(command))
        msg = json.loads(await ws.recv())
        if not msg.get("success", False):
            raise RuntimeError(f"WS command failed: {msg}")
        return msg.get("result", {})

# ---------------------------------------------------------------------------
# REST helpers
# ---------------------------------------------------------------------------

async def get_states(entity_filter: str = "") -> list[dict]:
    """Return entity states, optionally filtered by prefix."""
    url = f"{HA_URL}/api/states"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            states = await resp.json()
    if entity_filter:
        states = [s for s in states if s["entity_id"].startswith(entity_filter)]
    return states


async def get_error_log(domain: str = "", since_minutes: int = 30) -> str:
    """Return the HA error log, optionally filtered to *domain* entries."""
    url = f"{HA_URL}/api/error_log"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            log_text = await resp.text()
    if domain:
        log_text = "\n".join(
            line for line in log_text.splitlines() if domain in line
        )
    return log_text


async def check_integration_loaded(domain: str) -> bool:
    """Return True if *domain* appears in the list of loaded components."""
    url = f"{HA_URL}/api/config"
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            config = await resp.json()
    return domain in config.get("components", [])


async def call_service(domain: str, service: str, data: dict | None = None) -> dict:
    """Call a Home Assistant service via REST."""
    url = f"{HA_URL}/api/services/{domain}/{service}"
    async with aiohttp.ClientSession() as session:
        async with session.post(url, json=data or {}, headers=_rest_headers()) as resp:
            resp.raise_for_status()
            return await resp.json()


async def restart_and_wait(timeout_seconds: int = 180) -> bool:
    """Restart Home Assistant and wait until the API is responsive again."""
    url = f"{HA_URL}/api/services/homeassistant/restart"
    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(
                url, json={}, headers=_rest_headers(),
                timeout=aiohttp.ClientTimeout(total=30),
            ) as resp:
                resp.raise_for_status()
    except (aiohttp.ClientError, OSError, asyncio.TimeoutError):
        pass  # restart often kills the connection before responding

    # Wait for HA to come back
    loop = asyncio.get_running_loop()
    deadline = loop.time() + timeout_seconds
    await asyncio.sleep(10)  # give HA time to start shutting down
    while loop.time() < deadline:
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(
                    f"{HA_URL}/api/",
                    headers=_rest_headers(),
                    timeout=aiohttp.ClientTimeout(total=10),
                ) as resp:
                    if resp.status == 200:
                        return True
        except (aiohttp.ClientError, OSError, asyncio.TimeoutError):
            pass
        await asyncio.sleep(5)
    return False

# ---------------------------------------------------------------------------
# HACS WebSocket commands
# ---------------------------------------------------------------------------

async def hacs_add_repository(repository: str, category: str = "integration") -> dict:
    """Register a custom repository in HACS."""
    return await _ws_send_command({
        "type": "hacs/repositories/add",
        "repository": repository,
        "category": category,
    })


async def hacs_install(repository: str, version: str = "") -> dict:
    """Install / update a HACS repository via the WebSocket API.

    Ensures the repository is registered first, then downloads it.
    """
    # Step 1: Add/register the repository in HACS (idempotent — no error if already added)
    try:
        await hacs_add_repository(repository)
    except RuntimeError:
        pass  # already registered, that's fine

    # Step 2: Download — HACS expects the GitHub repo slug, not a numeric ID
    command: dict = {
        "type": "hacs/repository/download",
        "repository": repository,
    }
    if version:
        command["version"] = version
    return await _ws_send_command(command)


async def hacs_list_repositories() -> list[dict]:
    """List repositories known to HACS."""
    return await _ws_send_command({"type": "hacs/repositories/list"})


async def remove_config_entries(domain: str) -> int:
    """Remove all config entries for *domain* and return the count removed."""
    entries = await _ws_send_command({"type": "config_entries/get"})
    removed = 0
    if isinstance(entries, list):
        for entry in entries:
            if entry.get("domain") == domain:
                await _ws_send_command({
                    "type": "config_entries/delete",
                    "entry_id": entry["entry_id"],
                })
                removed += 1
    return removed