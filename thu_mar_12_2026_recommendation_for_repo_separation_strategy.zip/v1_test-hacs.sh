# Test that HACS WebSocket API responds
# Install wscat if needed: npm install -g wscat
# Or use Python one-liner:

python3 -c "
import asyncio, json, websockets
async def test():
    async with websockets.connect('ws://192.168.1.37:8123/api/websocket') as ws:
        print(await ws.recv())  # auth_required
        await ws.send(json.dumps({'type': 'auth', 'access_token': 'YOUR_TOKEN'}))
        print(await ws.recv())  # auth_ok
        await ws.send(json.dumps({'id': 1, 'type': 'hacs/repositories/list'}))
        resp = json.loads(await ws.recv())
        print(f'Success: {resp.get(\"success\")}')
        if resp.get('success'):
            print(f'HACS repos: {len(resp.get(\"result\", []))}')
        else:
            print(f'Error: {resp}')
asyncio.run(test())
"