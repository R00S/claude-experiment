curl -s -H "Authorization: Bearer YOUR_TOKEN" \
  http://192.168.1.37:8123/api/config | python3 -c "
import sys, json
config = json.load(sys.stdin)
comps = config.get('components', [])
hacs = [c for c in comps if 'hacs' in c]
print('HACS components found:', hacs if hacs else 'NONE')
"