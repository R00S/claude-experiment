async def hacs_install(repository: str, version: str = "") -> dict:
    command: dict = {
        "type": "hacs/repository/download",
        "repository": repository,
    }
    if version:
        command["version"] = version
    return await _ws_send_command(command)