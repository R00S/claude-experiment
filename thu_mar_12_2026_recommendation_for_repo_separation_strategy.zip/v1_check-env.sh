cd /path/to/ha-dev-platform
cat .env