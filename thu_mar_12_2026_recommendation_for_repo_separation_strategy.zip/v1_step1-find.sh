# Find the repo
docker exec ha-dev-orchestrator ls /app/src/