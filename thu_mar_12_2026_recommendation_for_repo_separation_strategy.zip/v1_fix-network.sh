# Stop the existing container
docker stop ha-dev-platform  # or whatever the container name is

# Re-run with host networking
docker run --network host \
  ... (your existing flags/env vars) \
  your-mcp-bridge-image