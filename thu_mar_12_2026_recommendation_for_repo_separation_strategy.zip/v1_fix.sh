cd /path/to/ha-dev-platform

# Edit docker-compose.yml
nano docker-compose.yml