# Exit the container shell
exit

# Restart the container to pick up changes
docker restart ha-dev-orchestrator